import random #импорт рандома
import pygame as pg # пайгейм как пг (сокращение)
pg.init() #подключение пакетов библеотеки
print('тут будут очки') # вывод очков в консоль
platf = pg.image.load('platf 100x100.png') # загрузка платформы
ball = pg.image.load('ball 30x30.png') # загрузка шарика
block = pg.image.load('block.png') # загрузка блока
platf = pg.transform.scale(platf, (700, 700))# изменение размера платформы
ball = pg.transform.scale(ball, (50, 50)) # изменение размера шарика
block = pg.transform.scale(block, (50, 50))# изменение размера блока

xPlatf = 50 # х платформы
yPLatf = 200 # у платформы
xSpeed = 0 # изначальная скорость платформы

xBall = 350 # x шарика
yBall = 50 # у шарика
xspBall = 5 # скорость шарика по х
yspBall = 5 # скорость шарика по у

score = 0 #очки
font = pg.font.SysFont('sherif', 48) # загрузка шрифта


xBlock = random.randint(10,300)#рандомный спавн блока по х
yBlock = random.randint(10,400)#рандомный спавн блока по у

loose = False #выключение проигрыша для того что бы его не было сразу


scr = pg.display.set_mode((800, 800)) #создание дисплея
while True: # цикл

    scr.fill((0, 0, 0)) #заполнение экрана цветом(черным)
    while loose: # цикл проигрыша
        scr.fill((255, 0, 0)) # заполнение цветом экрана при проигрыше
        for i in pg.event.get(): # оприделение события
            if i.type == pg.QUIT: # тип события
                exit() # событие выхода

        pg.display.flip() #обновление дисплея


    scr.blit(platf, (xPlatf,yPLatf)) # вывод на экран платформы
    scr.blit(ball, (xBall,yBall)) #вывод на экран шарика
    scr.blit(block, (xBlock,yBlock)) # вывод на экран блока

    pg.draw.rect(scr, (255, 0, 0), (0, 0, 10, 900)) # вывод первой стенки
    pg.draw.rect(scr, (255, 0 , 0), (0, 0, 900, 10)) # вывод второй стенки
    pg.draw.rect(scr, (255, 0, 0), (790, 0, 10, 900)) # вывод третей стенки
    pg.draw.rect(scr, (255, 0, 0), (0, 790, 900, 10)) # вывод четвертой стенки


    left = scr.get_at((int(xBall - 7),int (yBall + 10))) # левый сенсор
    right = scr.get_at((int (xBall + 10), int (yBall + 10))) # правый сенсор
    up = scr.get_at(( int (xBall + 10), int(yBall - 1))) # верхний сенсор
    down = scr.get_at((int(xBall + 0), (yBall + 51))) # нижний сенсор

    if left == (255, 0, 0) or right == (255, 0, 0): # условие
        xspBall = + 10 # выполнение условия
    if up == (255, 0, 0) or down == (255, 0, 0): # условие
        yspBall = + 5 # выполнение условия
    if down == (181, 165, 213): # условие
        yspBall = -5 # выполнение условия
    if down == (255,0,0): # условие
        loose = True # выполнение условия
    if left == (111,49,152) or right == (111,49,152) or up == (111,49,152) or down == (111,49,152): # условие
        xspBall += random.randint(1, 5)/10 # добавление скорости шарику
        score += 1 # добавление очков
        print(score) # вывод очков к консол
        xBlock = random.randint(15, 700) # рандомное перемещение блока по х
        yBlock = random.randint(15, 300) # рандомное перемещение блока по у



    if xPlatf > 180 or xPlatf <= -121: # ограниение перемещения платформы
        xSpeed = 0 # скорость платформы 0 если превышает 180 и -121
    if xBall > 750: # отражение скорости шарика
        xspBall = -10 # скорость щарика по х отрожаеться если он привышает координату 750
    if xBall < 0: # условие если координата шарика меньше 0
        xspBall = 10 # выполнение условие если условие выполняеться то скорость шарика 10
    if yBall < 50:  # условие если координата шарика меньше 50
        yspBall = 10 # выполнение условие если условие выполняеться то скорость шарика 10


    text = font.render(str(score), True, (255,0,0))  #параметры текста
    scr.blit(text, (10,15)) # вывод текста

    for i in pg.event.get():  # оприделение события
        if i.type == pg.QUIT:  # тип события
            exit()  # событие выхода

        if i.type == pg.KEYDOWN: # определение типа кнопки
            if i.key == pg.K_RIGHT and xPlatf < 180: # нажатие кнопки
                xSpeed =  + 10 # при нажатие кнопки сделать скорость платформы 10
            if i.key == pg.K_LEFT and xPlatf > 121: # нажатие кнопки
                xSpeed =   - 10 # при нажатие кнопки сделать скорость платформы 10 ( в обратную сторону)

        if i.type == pg.KEYUP: # определение типа кнопки
            if i.key == pg.K_RIGHT: # отжатее кнопки
                xSpeed = 0 # при отжатии кнопку сделать скорость платформы 0
            if i.key == pg.K_LEFT: # отжатие кнопки
                xSpeed = 0 # при отжатии кнопку сделать скорость платформы 0

    xPlatf += xSpeed # движине платформы
    xBall += xspBall # движиние шара по х
    yBall += yspBall # движиние шара по у
    pg.display.flip() # обновление дисплея